<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Application rules
- Keep prototype data in a shared React context mounted above the route outlet so demo actions survive navigation without implying real persistence.
- Give each dashboard destination its own leaf route and metadata, sharing workspace panels to keep the personal and organization experience consistent.
- Keep every emergency and assistant outcome explicitly simulated so the prototype cannot be mistaken for dispatch or medical advice.
