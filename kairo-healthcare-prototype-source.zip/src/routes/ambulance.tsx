import { createFileRoute } from '@tanstack/react-router';
import { AmbulanceView } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/ambulance')({
 head: () => pageHead('Ambulance care', 'Explore clearly simulated ambulance requests and tracking.'),
 component: AmbulanceView,
});
