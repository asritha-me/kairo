import { createFileRoute } from '@tanstack/react-router';
import { Overview } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/')({
 head: () => pageHead('Overview', 'Your personal healthcare overview, appointments, records and care companion.'),
 component: Overview,
});
