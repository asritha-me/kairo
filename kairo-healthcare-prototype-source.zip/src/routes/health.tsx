import { createFileRoute } from '@tanstack/react-router';
import { Health } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/health')({
 head: () => pageHead('My health', 'Track sample health readings and explore your care history.'),
 component: Health,
});
