import { createFileRoute } from '@tanstack/react-router';
import { Reports } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/reports')({
 head: () => pageHead('Health reports', 'View and download fictional health reports in Kairo.'),
 component: Reports,
});
