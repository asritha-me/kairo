import { createFileRoute } from '@tanstack/react-router';
import { Patients } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/patients')({
 head: () => pageHead('Patient directory', 'Explore fictional hospital patient records and care plans.'),
 component: Patients,
});
