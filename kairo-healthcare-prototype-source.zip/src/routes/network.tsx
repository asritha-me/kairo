import { createFileRoute } from '@tanstack/react-router';
import { Network } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/network')({
 head: () => pageHead('Hospital network', 'Explore hospital equipment and simulated patient transfers.'),
 component: Network,
});
