import { createFileRoute } from '@tanstack/react-router';
import { Assistant } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/assistant')({
 head: () => pageHead('Kairo assistant', 'A sample care companion for reports and appointment preparation.'),
 component: Assistant,
});
