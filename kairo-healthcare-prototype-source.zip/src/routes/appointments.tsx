import { createFileRoute } from '@tanstack/react-router';
import { Appointments } from '@/components/kairo/panels';
import { pageHead } from '@/lib/demo';
export const Route = createFileRoute('/appointments')({
 head: () => pageHead('Appointments', 'Explore care teams and book a simulated healthcare appointment.'),
 component: Appointments,
});
