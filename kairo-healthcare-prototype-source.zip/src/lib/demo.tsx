import { createContext, useContext, useState, type ReactNode } from 'react';
export type Appointment = { id: string; doctor: string; specialty: string; date: string; time: string };
type Demo = { organization: boolean; setOrganization: (v: boolean) => void; appointments: Appointment[]; addAppointment: (a: Appointment) => void; ambulance: boolean; setAmbulance: (v: boolean) => void; transfer: boolean; setTransfer: (v: boolean) => void };
const DemoContext = createContext<Demo | null>(null);
export function DemoProvider({children}: {children: ReactNode}) {
 const [organization,setOrganization] = useState(false); const [ambulance,setAmbulance]=useState(false); const [transfer,setTransfer]=useState(false);
 const [appointments,setAppointments]=useState<Appointment[]>([{id:'1',doctor:'Dr. Ananya Sharma',specialty:'General physician',date:'2026-10-08',time:'10:30'},{id:'2',doctor:'Dr. Arjun Mehta',specialty:'Cardiologist',date:'2026-10-12',time:'14:00'}]);
 return <DemoContext.Provider value={{organization,setOrganization,appointments,addAppointment:a=>setAppointments(p=>[...p,a]),ambulance,setAmbulance,transfer,setTransfer}}>{children}</DemoContext.Provider>;
}
export function useDemo(){const value=useContext(DemoContext); if(!value) throw new Error('DemoProvider required'); return value;}
export function pageHead(title:string,description:string){return {meta:[{title:`${title} · Kairo`},{name:'description',content:description},{property:'og:title',content:`${title} · Kairo`},{property:'og:description',content:description},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]};}
