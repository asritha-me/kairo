# Kairo prototype
- [ ] Design tokens and collapsible dashboard shell
- [ ] Patient health, appointments, reports, assistant and simulated emergency flow
- [ ] Organization patient records, ambulances and transfers
- [ ] Verify core interactions and screen layout